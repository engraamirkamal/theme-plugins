jQuery(document).ready(function(){
	jQuery('.pmpro-datepicker').datepicker();	
});