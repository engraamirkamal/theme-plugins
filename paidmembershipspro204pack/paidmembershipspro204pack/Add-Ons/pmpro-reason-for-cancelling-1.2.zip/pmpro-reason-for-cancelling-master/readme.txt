=== PMPro Reason for Cancelling ===
Contributors: strangerstudios, pbrocks
Tags: pmpro, membership, reason, cancel
Requires at least: 3.5
Tested up to: 4.9.7
Stable tag: .1.2

Require members to provide a reason for leaving before they can cancel their memmbership.
This reason will be added to the emails sent to both the user and administrator.

== Description ==

Features:
* Require members to provide a reason for leaving before they can cancel their memmbership.

Simply activate the plugin and a new checkout page template will be used, requiring your users to enter a reason, before they can cancel their membership.
The reason will be added to the emails sent to both the user and administrator.

== Installation ==

1. Upload the `pmpro-reason-for-cancelling` directory to the `/wp-content/plugins/` directory of your site.
1. Activate the plugin through the 'Plugins' menu in WordPress.

== Frequently Asked Questions ==

= I found a bug in the plugin. =

Please post it in the issues section of GitHub and we'll fix it as soon as we can. Thanks for helping. https://github.com/strangerstudios/pmpro-reason-for-cancelling/issues

== Changelog ==
= .1.2 =
* Prepared for translation

= .1.1 =
* Added readme.txt

= .1 =
* Initial version of the plugin.