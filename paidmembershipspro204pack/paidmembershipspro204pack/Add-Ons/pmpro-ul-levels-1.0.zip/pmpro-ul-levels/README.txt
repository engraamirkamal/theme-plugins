=== PMPro Levels as UL Layout ===
Contributors: strangerstudios
Tags: paid memberships pro, pmpro, memberships, ecommerce
Requires at least: 3.0
Tested up to: 3.5.1
Stable tag: .1

The default PMPro Membership Levels page displays in a table layout. This plugin loops through your levels as LI items and puts the level information in a UL as well. If you are using a the PMPro Level Cost Text add on, it will use that text for the generated price sentence. Alternately, it will just use the automatically generated level cost text PMPro provides. This plugin is particularly effective if you are using the Foundation by ZURB.

== Description ==
This plugin requires Paid Memberships Pro to function.

Display your Membership Levels in a UL layout, allowing you to add custom CSS to create a more interesting Membership Levels page appearance.

== Installation ==

1. Upload the `pmpro-ul-levels` directory to the `/wp-content/plugins/` directory of your site.
1. Activate the plugin through the 'Plugins' menu in WordPress.
1. That's it. No settings.

== Changelog == 
= .1 =
* Initial release

