MCW FullPage for WPBakery Page Builder
Plugin URL: https://www.meceware.com/fp/

INTRODUCING – FULLPAGE FOR WPBakery Page Builder

--------------------------------------------------

Now, create beautiful scrolling fullscreen web sites with WPBakery Page Builder, fast and simple.
This plugin simplifies creation of fullscreen scrolling websites with WordPress and saves you big time.

Top Features
  - Fully responsive.
  - Touch support for mobiles, tables, touch screen computers.
  - Each row as a full page section. Full page sections are the vertical slides.
  - Optional columns as slides. If selected, each column behaves as horizontal slides.
  - Full page scroll with optional visible scrollbar.
  - Optional Auto-height sections.
  - CSS3 and (optional) JS animations.
  - Animated anchor links.
  - Optional show/hide anchor links in the address bar.
  - Optional vertically centered row content.
  - Optional text resize when window is resized.
  - Optional section and slide loops.
  - Optional section only scrollbars.
  - Optional keyboard support while scrolling.
  - Optional history record. When this is enabled, browser back button will go to the previous section.
  - Optional horizontal and vertical navigation bars.
  - Optional responsive scrollbar. When responsive width and height given, a normal scroll page will be used under the given width and height values.
  - TEMPLATES: You can use empty page templates or supply your own page template. (Note: Templates does not change WordPress header and footer, only the content.)
  - CSS and JS minified.
  - Use with any theme.

How To Use

To use FullPage for WPBakery Page Builder,
  - You can use predefined FullPage for WPBakery Page Builder template.
  - You can use your own template. Copy 'template' folder in the plugin folder, make changes on it and copy it to your server. Then copy the path name to 'Template Path' option in Full Page settings.
  - The theme must have an empty page template. Most professional themes have empty page templates and this plugin can be used with them with minor CSS modifications. For BeTheme and Avada please use support for help.

1. Insert rows with WPBakery Page Builder. Rows will be defines as full page sections when Full Page is enabled.
2. Design the row content. WPBakery Page Builder animations are supported only for the first row if scrollbars are disabled.
3. Enable Full Page using the meta box. The meta box is shown only for the pages WPBakery Page Builder enabled. For custom post types, please enable WPBakery Page Builder to use FullPage for WPBakery Page Builder.
4. Play with Full Page options. Please use support for any questions.
5. Enable empty page template to redirect content template to an empty one, if necessary.

Credits

Thanks to Álvaro Trigo for awesome fullpage.js plugin.