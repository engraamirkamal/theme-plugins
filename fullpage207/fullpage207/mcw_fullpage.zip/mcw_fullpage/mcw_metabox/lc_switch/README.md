LC Switch
==============

Superlight jQuery plugin improving forms look and functionality. 

Give a modern and flat look to your applications and take advantage of events and public functions. Everything in **just 5KB**, all inclusive!

Requires at least jQuery v1.7 and supports all browsers (yes, also old IE, up to version 7)

For **documentation** and usage notes check:
https://lcweb.it/lc-switch-jquery-plugin



* * *


Copyright &copy; Luca Montanari - LCweb 
