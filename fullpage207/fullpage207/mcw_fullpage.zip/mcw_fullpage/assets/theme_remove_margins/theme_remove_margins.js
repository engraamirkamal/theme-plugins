// Add class to remove margins
$('#mcw_full_page').parentsUntil('body').addClass('mcw_fp_nomargin');
$('.mcw_fp_fixed_top,.mcw_fp_fixed_bottom').addClass('mcw_fp_nomargin');
